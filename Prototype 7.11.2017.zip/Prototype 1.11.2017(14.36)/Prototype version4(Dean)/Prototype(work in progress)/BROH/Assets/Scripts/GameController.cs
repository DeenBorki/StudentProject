﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

	private bool PlayerHitFinishLine = false;

	// Use this for initialization
	void Start ()
	{
		GameObject theTimer = GameObject.Find ("Timer");
		TimerController timerController = theTimer.GetComponent<TimerController> ();
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (PlayerHitFinishLine == true)
		{
			if (Input.GetKeyDown(KeyCode.R))
			{
				PlayerPrefs.SetString ("Highscore", TimerController.CurrentScore);
				SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
			}
		}
	}

	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "jeep")
		{
			PlayerHitFinishLine = true;
		}
	}
}

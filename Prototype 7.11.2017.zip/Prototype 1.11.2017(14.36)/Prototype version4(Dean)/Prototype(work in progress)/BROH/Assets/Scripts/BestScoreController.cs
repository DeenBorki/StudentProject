﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BestScoreController : MonoBehaviour {

	public string TopScore;

	// Use this for initialization
	void Start ()
	{
		TopScore = PlayerPrefs.GetString ("Highscore");
		gameObject.GetComponent<Text> ().text = "Last Run: " + TopScore;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

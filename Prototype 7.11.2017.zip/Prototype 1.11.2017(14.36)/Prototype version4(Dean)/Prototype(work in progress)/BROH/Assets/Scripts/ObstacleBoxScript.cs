﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleBoxScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	//Activates classes when a player hits a box
	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "jeep")
		{
			col.gameObject.SendMessage ("OnBoxHitJeep");
			GameObject.Find ("Lane1").SendMessage ("OnBoxHitLanes");
			GameObject.Find ("Lane2").SendMessage ("OnBoxHitLanes");
			GameObject.Find ("Lane3").SendMessage ("OnBoxHitLanes");

			Destroy (gameObject);
		}
	}
}

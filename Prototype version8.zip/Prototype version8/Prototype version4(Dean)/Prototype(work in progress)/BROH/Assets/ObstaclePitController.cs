﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstaclePitController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	//Activates classes when a player hits a pit
	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "jeep")
		{
			col.gameObject.SendMessage ("");
			GameObject.Find ("Lane1").SendMessage ("O");
			GameObject.Find ("Lane2").SendMessage ("");
			GameObject.Find ("Lane3").SendMessage ("");
		}
	}
}

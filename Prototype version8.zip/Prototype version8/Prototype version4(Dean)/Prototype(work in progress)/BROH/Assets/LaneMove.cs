﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaneMove : MonoBehaviour {

	public Transform LaneMovement;
	public float speed;
	private bool MovingBool;
	// Use this for initialization
	void Start () {
		GameObject thePlayer = GameObject.Find ("jeep");
		LaneSwapping LaneSwappingScript = thePlayer.GetComponent<LaneSwapping>();

	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (Input.GetKey (KeyCode.Space)) {
			MovingBool = true;
		}
		if (MovingBool == true) {
			LaneMovement.position += transform.forward * Time.deltaTime * speed;
		}
	}		
//Run when player hits box-type obstacle, slows the lanes down to the same speed as the Jeep
	public IEnumerator OnBoxHitLanes()
	{
		speed = 2;
			yield return new WaitForSeconds(2);
		speed = 10;
	}

//Run when player hits speedboost obstacle, increases lanes speed to match the jeep
	public IEnumerator OnSpeedBoostHitLanes()
	{
		speed = 15;
			yield return new WaitForSeconds(2);
		speed = 10;
	}

	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "jeep")
		{
			
			GameObject.Find ("jeep").SendMessage ("LaneSwapped");
		}
	}
}

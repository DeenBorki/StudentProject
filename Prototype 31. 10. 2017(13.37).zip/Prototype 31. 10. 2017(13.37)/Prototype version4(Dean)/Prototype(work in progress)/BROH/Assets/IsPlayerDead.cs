﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class IsPlayerDead : MonoBehaviour {

	//True if player is not dead
	public bool IsDead = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (IsDead == true)
		{
			if (Input.GetKey(KeyCode.R))
			{
				SceneManager.LoadScene ("KoukoiProject");
			}
		}
	}

	public void PlayerIsDead()
	{
		IsDead = true;
	}
}

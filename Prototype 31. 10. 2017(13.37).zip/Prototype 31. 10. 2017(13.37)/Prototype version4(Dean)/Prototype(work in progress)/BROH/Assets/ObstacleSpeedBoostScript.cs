﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSpeedBoostScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	//Activates classes when a player hit speedboost
	void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "jeep")
		{
			col.gameObject.SendMessage ("SpeedBoostHitJeep");
			GameObject.Find ("Lane1").SendMessage ("OnSpeedBoostHitLanes");
			GameObject.Find ("Lane2").SendMessage ("OnSpeedBoostHitLanes");
			GameObject.Find ("Lane3").SendMessage ("OnSpeedBoostHitLanes");
		}
	}
}

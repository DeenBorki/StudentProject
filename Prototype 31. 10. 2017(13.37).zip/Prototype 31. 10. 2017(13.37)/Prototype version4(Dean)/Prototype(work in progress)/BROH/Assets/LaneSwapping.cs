﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaneSwapping : MonoBehaviour {

	//Speed for swapping and Time
	public float SwapSpeed;
	private float Smooth;
	private float CurrentTime;
	private float EndTime;

	//Transforms for Lane Swapping
	public GameObject Car;
	private Vector3 CurrentPosition;
	public Transform Lane1;
	public Transform Lane2; 
	public Transform Lane3;
	private Vector3 newPostion;
	private Vector3 PointA;
	private Vector3 PointB;




	//Swapping Bools
	private bool ActivateSwapping;
	private bool Swapping;

	//Hold number of lane
	private int Lane;
	private float PositionAX;
	private float PositionBX;
	private float SwappingDistance;
	// Use this for initialization
	void Start () {
		Lane = 2;
		ActivateSwapping = true;
		//Car.transform.position = Lane2.position;
		//PointA = transform.position;
		Smooth = SwapSpeed * Time.deltaTime;
		//CurrentPosition = Car.transform.position;
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (ActivateSwapping == true) {
			if (Lane == 1) {
				if (Input.GetKeyUp (KeyCode.D) || Input.GetKeyUp (KeyCode.RightArrow)) {
					//PointA = transform.position;
					newPostion = Lane2.transform.position;
					//PointB = Lane2.position;
					//transform.position = Vector3.Lerp (PointA, PointB, Smooth);
					//Car.transform.position = Lane2.position;
					Lane = 2;
				} 
			}
			if (Lane == 2) {
				//CurrentPosition = PositionA.position;
				//Checks which keys are pressed
				//If you try to go to the left lane 
				if (Input.GetKeyUp (KeyCode.A) || Input.GetKeyUp (KeyCode.LeftArrow)) {
					//PointA = transform.position;
					newPostion = Lane1.transform.position;
					//PointB = Lane1.position;
					CurrentTime = Time.time;

					//SwappingDistance = Vector3.Distance (CurrentPosition.position, newPostion.position);
					Swapping = true;
					//transform.position = Vector3.Lerp (PointA, PointB, Smooth);
					//transform.position.x = Mathf.Lerp (PointA, PointB, Time.deltaTime * SwapSpeed);
					//Car.transform.position = Lane1.position;
					Lane = 1;

				}
				//if you try to goto the right lane
				else if (Input.GetKey (KeyCode.D) || Input.GetKey (KeyCode.RightArrow)) {
					//Car.transform.position = Lane3.position;
					newPostion = Lane3.transform.position;
					Lane = 3;
				}
			}

			//if the lane is 3
			if (Lane == 3) {
				//If you try to go to the left lane 
				if (Input.GetKeyUp (KeyCode.A) || Input.GetKeyUp (KeyCode.LeftArrow)) {
					//Car.transform.position = Lane2.position;

					newPostion = Lane2.transform.position;
					Lane = 2;
				}
			}
		}

		if (Swapping == true) {
			//transform.position = Vector3.Lerpmove  (PointA, PointB, Smooth);
			/*float distCovered = (Time.time - CurrentTime) * SwapSpeed;
			float fracJourney = distCovered / SwappingDistance;
			transform.position = Vector3.Lerp (CurrentPosition.position, newPostion.position, fracJourney);*/

			Vector3 thisPosition = transform.position;
			thisPosition.x = Mathf.Lerp(thisPosition.x, newPostion.x, Time.deltaTime * SwapSpeed);
			transform.position = thisPosition;

		}
	}
	void LaneCheck(){
		
	}



}
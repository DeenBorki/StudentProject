﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	//Definitions for speed; 
	public float pitHitWaitTime = 1;
	public float speed = 2;
	public float SwapSpeed = 2 ;

	//objects 
	public GameObject ThisPlayer;
	private Transform ObjectPosition;

	// bools for the lanes and movement;
	private bool MovingBool;
	private bool ActivateSwapping;
	private bool Swapping;

	//Control for checking what lane.
	private int Lane;

	// Use this for initialization
	void Start () {
		ObjectPosition = ThisPlayer.transform;
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		if (Input.GetKey (KeyCode.Space)) {
			MovingBool = true;
		} else {
			//print ("Nothing is moving");
		}
		// lane swapping happends here
		if (MovingBool == true) {
			ObjectPosition.position += transform.forward * Time.deltaTime * speed;
		}
	}	

	//Run when player hits box-type obstacle, slows the player for a few seconds
	public IEnumerator OnBoxHitJeep()
	{
		speed = 2;
		yield return new WaitForSeconds(2);
		speed = 10;
	}

	//Run when player hits speedboost obstacle, increases players speed for a few seconds
	public IEnumerator SpeedBoostHitJeep()
	{
		speed = 15;
		yield return new WaitForSeconds(2);
		speed = 10;
	}

	//Moves player in front of the pit and stops the player for a few seconds
	public IEnumerator OnPitHit()
	{
		transform.Translate (Vector3.forward * 3);
		speed = 0;
		yield return new WaitForSeconds (pitHitWaitTime);
		speed = 10;
	}
}

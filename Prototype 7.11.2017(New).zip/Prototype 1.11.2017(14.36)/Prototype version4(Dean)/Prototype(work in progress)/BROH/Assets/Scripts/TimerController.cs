﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerController : MonoBehaviour {

	float GameTime = 0f;
	public static string CurrentScore;
	// Use this for initialization
	void Start ()
	{
		GameTime = 0f;
		gameObject.GetComponent<Text> ().text = GameTime.ToString ("F");
	}
	
	// Update is called once per frame
	void Update ()
	{
		GameTime += Time.deltaTime;
		gameObject.GetComponent<Text> ().text = GameTime.ToString ("F");
		CurrentScore = GameTime.ToString ("F");
	}
}
